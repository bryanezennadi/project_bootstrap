document.getElementById("bottoneTrasporto").addEventListener("click", function() {
    // Cambia la finestra attuale alla nuova pagina HTML
    window.location.href = "transportLayer.html";
});